#include "Cliente.h"

using namespace std;

Cliente::Cliente (int telefono_a_ingresar, float precio_a_ingresar){

	telefono = telefono_a_ingresar;
	precio_fijo = precio_a_ingresar;
	
}

int Cliente::obtener_telefono(){

	return telefono;

}

float Cliente::obtener_precio(){

	return precio_fijo;

}