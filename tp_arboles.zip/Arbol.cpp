#include "Arbol.h"

using namespace std;

Arbol::Arbol(){

	raiz = NULL;

}

//El nodo a buscar padre puede o no estar incluido en el arbol.
Nodo* Arbol::buscar_padre(Nodo* nodo_a_buscar_padre){
	return NULL;
}

void Arbol::agregar_cliente(Cliente* cliente_a_agregar){
	Nodo* nuevo_nodo = new Nodo(cliente_a_agregar);
	if(!raiz){
		raiz = nuevo_nodo;
	}
	else{
		//buscar_padre
	}

}