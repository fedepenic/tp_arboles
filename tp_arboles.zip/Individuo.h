#ifndef _INDIVIDUO_H_
#define _INDIVIDUO_H_

#include <string.h> 
#include "Cliente.h"

using namespace std;

float const DESCUENTO_INDIVIDUO = 0.10;

class Individuo: public Cliente{

	private:

		string nombre;

	public:
	
		Individuo (string nombre_a_ingresar, int telefono_a_ingresar, float precio_a_ingresar);	

		string obtener_nombre ();

		float calcular_descuento ();
};



#endif //_INDIVIDUO_H_