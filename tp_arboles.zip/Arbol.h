#ifndef _ARBOL_H_
#define _ARBOL_H_

#include "Nodo.h"

using namespace std;

class Arbol{

	private:

		Nodo* raiz;

	public:

		Arbol();

		Nodo* buscar_padre(Nodo* nodo_a_buscar_padre);

		void agregar_cliente(Cliente* cliente_a_agregar);


};



#endif //_ARBOL_H_