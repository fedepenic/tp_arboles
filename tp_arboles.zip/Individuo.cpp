#include "Individuo.h"

using namespace std;

Individuo::Individuo(string nombre_a_ingresar, int telefono_a_ingresar, float precio_a_ingresar)
					 :Cliente(telefono_a_ingresar, precio_a_ingresar){

	nombre = nombre_a_ingresar;

}

string Individuo::obtener_nombre(){

	return nombre;

}

float Individuo::calcular_descuento(){

	return (precio_fijo*DESCUENTO_INDIVIDUO);

}

