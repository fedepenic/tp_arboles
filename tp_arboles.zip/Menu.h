#ifndef _MENU_H_
#define _MENU_H_

#include "Arbol.h"

using namespace std;
	
class Menu{

	private:


	public:


};


#endif //_MENU_H_