#ifndef _CLIENTE_H_
#define _CLIENTE_H_

#include <iostream>

using namespace std;

class Cliente{

	protected: 

		int telefono;
		float precio_fijo;

	public:
		
		Cliente (int telefono_a_ingresar, float precio_a_ingresar);

		int obtener_telefono ();

		float obtener_precio();

		virtual float calcular_descuento () = 0;


};



#endif //_CLIENTE_H_