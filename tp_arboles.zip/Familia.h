#ifndef _FAMILIA_H_
#define _FAMILIA_H_

#include "Cliente.h"

using namespace std;

class Familia : public Cliente {

	private:
		 

};


#endif //_FAMILIA_H_