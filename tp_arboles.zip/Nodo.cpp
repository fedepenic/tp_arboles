#include "Nodo.h"

using namespace std;

Nodo::Nodo(){

	dato = NULL;
	sub_arbol_derecho = NULL;
	sub_arbol_izquierdo = NULL;

}

Nodo::Nodo(Cliente* nuevo_dato){

	dato = nuevo_dato;
	sub_arbol_derecho = NULL;
	sub_arbol_izquierdo = NULL;

}

Cliente* Nodo::obtener_dato(){

	return dato;

}

Nodo* Nodo::obtener_sub_arbol_derecho(){

	return sub_arbol_derecho;

}

Nodo* Nodo::obtener_sub_arbol_izquierdo(){

	return sub_arbol_izquierdo;

}

void Nodo::asignar_sub_arbol_derecho(Nodo* nuevo_sub_arbol_derecho){

	sub_arbol_derecho = nuevo_sub_arbol_derecho;

}

void Nodo::asignar_sub_arbol_izquierdo(Nodo* nuevo_sub_arbol_izquierdo){

	sub_arbol_izquierdo = nuevo_sub_arbol_izquierdo;

}
