#ifndef _NODO_H_
#define _NODO_H_

#include "Individuo.h"
#include <iostream>

using namespace std;

class Nodo{

	private:

		Cliente* dato;
		Nodo* sub_arbol_derecho;
		Nodo* sub_arbol_izquierdo;

	public:	

		Nodo();

		Nodo(Cliente* nuevo_dato);

		Cliente* obtener_dato();

		Nodo* obtener_sub_arbol_derecho();

		Nodo* obtener_sub_arbol_izquierdo();

		void asignar_sub_arbol_derecho(Nodo* nuevo_sub_arbol_derecho);

		void asignar_sub_arbol_izquierdo(Nodo* nuevo_sub_arbol_izquierdo);
};

#endif //_NODO_H_